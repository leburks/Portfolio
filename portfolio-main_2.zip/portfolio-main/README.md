# portfolio
This  portfolio is a small project using HTML / CSS and Bootstrap.
I will be using this to showcase my projects.
[Live Heroku Deployment] (https://portfolio-leashia.herokuapp.com/)


##screenshort.

![118e66b7-b588-4769-9af7-76d693666486](https://user-images.githubusercontent.com/71715738/194779864-30eb5b05-2eec-4f33-878a-13550931157a.png)
